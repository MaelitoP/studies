package model;

@FunctionalInterface
public interface EntityDeadEvent
{
    void execute(Game game);
}
