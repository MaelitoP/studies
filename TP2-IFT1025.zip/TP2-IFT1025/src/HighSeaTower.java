import controller.GameController;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import model.EntityDeadEvent;
import model.Game;
import view.GameView;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * HighSeaTower Game for IFT1025 course
 * @author Maël LE PETIT
 * @version 0.1
 */
public class HighSeaTower extends Application
{
    GameController hst;
    EntityDeadEvent deadEvent;
    ScheduledExecutorService executor;

    @Override
    public void start(Stage primaryStage)
    {
        hst = new GameController(); // Game controller

        primaryStage.setTitle("High Sea Tower");
        primaryStage.setResizable(false);
        primaryStage.getIcons().add(new Image("/ressource/jellyfish1.png"));

        AnimationTimer timer = new AnimationTimer()
        {
            private long lastTime = 0;

            @Override
            public void handle(long now)
            {
                if (lastTime == 0)
                {
                    lastTime = now;
                    return;
                }

                double deltaTime = (now - lastTime) * 1e-9; // Get time in seconds

                // Restart the game
                deadEvent = (game) -> game.restart();
                if(hst.getGame().getPlayer().isDead())
                {
                    hst.getGameView().getGC().clearRect(0, 0, GameView.WIDTH, GameView.HEIGHT);
                    hst.getGameView().reset();
                    deadEvent.execute(hst.getGame());
                }

                // Game thread
                hst.update(deltaTime, hst.getGameView().getGC());
                hst.draw(hst.getGameView().getGC(), hst.getGameView().getOffsetY());

                lastTime = now;
            }
        };
        timer.start();

        // Bubble task
        Runnable helloRunnable = () -> { if(Game.isStarted) hst.getGame().sendBubble(); };
        executor = Executors.newScheduledThreadPool(0);
        executor.scheduleAtFixedRate(helloRunnable, 0, 3, TimeUnit.SECONDS);

        primaryStage.setScene(hst.getGameView().getScene());
        primaryStage.show();
        primaryStage.setOnCloseRequest(event -> executor.shutdown()); // Stop bubble animation thread
    }

    public static void main(String[] args)
    {
        launch(args);
    }
}