package controller;

import javafx.scene.canvas.GraphicsContext;
import model.Game;
import model.Platform;
import view.GameView;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

public class GameController
{
    private GameView gameView;
    private Game game;
    private boolean debug;
    private ScheduledExecutorService thread;

    public GameController()
    {
        Game.isStarted = false;
        this.gameView = new GameView();
        this.game = new Game();
        this.registerEvent(); // Register key pressed event
        this.debug = false;
    }

    public void setThread(ScheduledExecutorService e) { this.thread = e; }

    public void update(double time)
    {
        this.game.updateBubbles(time, this.gameView.getOffsetY());
        if(Game.isStarted)
        {
            this.gameView.update(time, this.game.getPlayer());
            this.game.update(time, this.gameView.getOffsetY(), this.gameView);
        }
    }

    public void draw(GraphicsContext context, double offsetY)
    {
        this.gameView.draw();
        this.game.draw(context, offsetY);
        this.game.drawBubbles(context, offsetY);
    }

    public void debug()
    {
        if(debug)
        {
            // Turn off debug
            this.gameView.setDebug(false);
            this.game.getPlayer().setDebug(false);
            this.game.setDebug(false);
            for(Platform p : this.game.getPlatforms())
                p.setDebug(false);
            this.debug = false;
        }
        else
        {
            // Turn on debug
            this.gameView.setDebug(true);
            this.game.getPlayer().setDebug(true);
            this.game.setDebug(true);
            for(Platform p : this.game.getPlatforms())
                p.setDebug(true);
            this.debug = true;
        }
    }

    public void registerEvent()
    {
        this.gameView.getScene().setOnKeyPressed(e -> {
                switch(e.getCode())
                {
                    case LEFT:
                        if(!Game.isStarted) Game.isStarted = true;
                        this.game.getPlayer().setLeft(true);
                        break;
                    case RIGHT:
                        if(!Game.isStarted) Game.isStarted = true;
                        this.game.getPlayer().setRight(true);
                        break;
                    case SPACE:
                        if(!Game.isStarted)
                         {
                            this.game.getPlayer().onGround(true);
                            Game.isStarted = true;
                        }
                        this.game.getPlayer().jump();
                        if(this.getGameView().isAccelerate())
                            this.getGame().stopAcc(this.gameView);

                        break;
                    case UP:
                        if(!Game.isStarted)
                        {
                            this.game.getPlayer().onGround(true);
                            Game.isStarted = true;
                        }
                        this.game.getPlayer().jump();
                        if(this.getGameView().isAccelerate())
                            this.getGame().stopAcc(this.gameView);
                        break;
                    case ESCAPE:
                        if(thread != null) thread.shutdown();
                        javafx.application.Platform.exit();
                        break;
                    case T:
                        debug();
                        break;
                }
            });

        this.gameView.getScene().setOnKeyReleased(e -> {
            switch(e.getCode())
            {
                case LEFT:
                    this.game.getPlayer().setLeft(false);
                    break;
                case RIGHT:
                    this.game.getPlayer().setRight(false);
                    break;
                case SPACE:
                    this.game.getPlayer().setJumping(false);
                    break;
                case ESCAPE:
                    javafx.application.Platform.exit();
                    break;
                case T:
                    break;
            }
        });
    }

    public Game getGame()
    {
        return this.game;
    }

    public GameView getGameView()
    {
        return this.gameView;
    }
}
