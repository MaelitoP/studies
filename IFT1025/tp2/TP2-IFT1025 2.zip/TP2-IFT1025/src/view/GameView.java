package view;

import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import model.Jellyfish;
import model.Platform;

public class GameView
{
    public static int WIDTH = 350, HEIGHT = 480;
    private double offsetY, vy, ay;
    private double vySave;
    protected boolean accelerate;
    private Scene scene;
    private Canvas canvas;
    private boolean debug = false;
    private Pane root;
    private Platform acceleratePlat;
    private GraphicsContext gc;

    public GameView()
    {
        this.root = new Pane();
        this.scene = new Scene(root, WIDTH, HEIGHT);
        this.canvas = new Canvas(WIDTH, HEIGHT);
        this.gc = this.canvas.getGraphicsContext2D();
        this.root.getChildren().add(this.canvas);
        this.accelerate = false;
        this.vy = -50;
        this.ay = 0;
        this.offsetY = 0;
    }

    public void reset()
    {
        this.accelerate = false;
        this.vy = -50;
        this.ay = 0;
        this.offsetY = 0;
        this.setDebug(false);
    }

    public double getOffsetY() { return this.offsetY; }

    public void setOffsetY(double offsetY) { this.offsetY = offsetY; }

    public void setDebug(boolean b)
    {
        if(b)
        {
            vySave = vy;
            vy = 0;
            ay = 0;
            debug = true;
        }
        else
        {
            if (vy == 0 && ay == 0)
            {
                vy = vySave;
                ay = 2;
            }
            debug = false;
        }
    }

    public void update(double dt, Jellyfish player)
    {
        vy += Math.pow(dt, 2) * ay;
        this.offsetY += dt * vy;

        if(Math.abs(player.getY()-HEIGHT) > 0.75*HEIGHT)
            this.offsetY += dt * -(Math.abs(player.getY()-HEIGHT) - 0.75*HEIGHT);

        if(!debug)
        {
            if(accelerate) player.setY(acceleratePlat.getY() - offsetY - 50);
            if(acceleratePlat != null)
                if(!player.testPlatformCollision(acceleratePlat, offsetY) && accelerate && !player.isOnGround())
                {
                    vy /= 2;
                    accelerate = false;
                }
            ay += -2;
        }
        else ay = 0;
    }

    public void setVy(double vy) { this.vy = vy; }
    public double getVy() { return this.vy; }

    public void setAccelerate(boolean b, Platform p)
    {
        this.accelerate = b;
        this.acceleratePlat = p;
    }
    public boolean isAccelerate() { return this.accelerate; }

    public void draw()
    {
        this.gc.clearRect(0, 0, WIDTH, HEIGHT);
        this.gc.setFill(Color.DARKBLUE);
        this.gc.fillRect(0, 0, WIDTH, HEIGHT);
    }

    public Scene getScene()
    {
        return this.scene;
    }

    public GraphicsContext getGC()
    {
        return this.gc;
    }
}