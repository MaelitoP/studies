package model;

import javafx.scene.paint.Color;
import javafx.scene.canvas.GraphicsContext;
import view.GameView;

import java.util.Random;

enum PlatformType
{
    RED(Color.rgb(184, 15, 36)),
    YELLOW(Color.rgb(230, 221, 58)),
    ORANGE(Color.rgb(230, 134, 58)),
    GREEN(Color.LIGHTGREEN);

    private Color c;

    PlatformType(Color c)
    {
        this.c = c;
    }

    protected Color getColor() { return this.c; }
}

public class Platform extends Entity
{
    private PlatformType type;
    private boolean drawDebug;

    public Platform(double x, double y, PlatformType type)
    {
        this.height = 10;
        this.width = new Random().nextInt((175 - 80) + 1) + 80; // Random width in range [80-175]px
        this.x = initXValuePlatform();
        this.y = y;
        this.type = type;
        this.color = type.getColor();
    }

    public void setDrawDebug(boolean b) { this.drawDebug = b; }
    public boolean getDrawDebug() { return this.drawDebug; }

    public PlatformType getType()
    {
        return this.type;
    }

    public double initXValuePlatform()
    {
        double x = Math.random() * GameView.WIDTH;
        if (x + 80 > GameView.WIDTH) x = GameView.WIDTH - 80; // right limit borne
        if(x < 0) x = 0; // left limit borne
        return x;
    }

    @Override
    public void update(double dt, double offsetY)
    {
        if (x + 80 > GameView.WIDTH) x = GameView.WIDTH - 80; // right limit borne
        if(x < 0) x = 0; // left limit borne
    }

    @Override
    public void draw(GraphicsContext context, double offsetY)
    {
        if(drawDebug)
            context.setFill(Color.YELLOW);
        else context.setFill(color);

        context.fillRect(this.x, this.y - offsetY, this.width, this.height);
    }
}
