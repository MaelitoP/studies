package model;

/**
 * Made an event called when the jelly's die
 * (see 'HighSeaTower.class')
 */
@FunctionalInterface
public interface EntityDeadEvent
{
    void execute(Game game);
}
