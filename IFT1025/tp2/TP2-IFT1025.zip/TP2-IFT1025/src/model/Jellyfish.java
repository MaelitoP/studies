package model;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import view.GameView;

/**
 * Player class
 */
public class Jellyfish extends Entity
{
    private Image[] framesR, framesL; // left & right image frames
    private Image image;
    private double frameRate = 8; // par second
    private double time = 0;

    public Jellyfish(double x, double y)
    {
        this.x = x;
        this.y = y;
        this.width = 50;
        this.height = 50;

        this.vx = 0; // x velocity
        this.vy = 0;

        this.ay = 1200; // gravity
        this.ax = 0;

        this.dead = false;

        // Spirits load
        framesR = new Image[]{
                new Image("./ressource/jellyfish1.png"),
                new Image("./ressource/jellyfish2.png"),
                new Image("./ressource/jellyfish3.png"),
                new Image("./ressource/jellyfish4.png"),
                new Image("./ressource/jellyfish5.png"),
                new Image("./ressource/jellyfish6.png")
        };
        framesL = new Image[]{
                new Image("./ressource/jellyfish1g.png"),
                new Image("./ressource/jellyfish2g.png"),
                new Image("./ressource/jellyfish3g.png"),
                new Image("./ressource/jellyfish4g.png"),
                new Image("./ressource/jellyfish5g.png"),
                new Image("./ressource/jellyfish6g.png")
        };
        image = framesL[0];
    }

    public void setDead(boolean b) { this.dead = b; }
    public boolean isDead() { return this.dead; }

    public void setY(double y) { this.y = y; }
    public void setVy(double vy) { this.vy = vy; }

    public void reset(double x, double y)
    {
        this.x = x;
        this.y = y;
        this.width = 50;
        this.height = 50;

        this.vx = 0; // x velocity
        this.vy = 0;

        this.ay = 1200; // gravity
        this.ax = 0;
    }

    public boolean isJumping() { return this.jumping; }

    @Override
    public void update(double dt, double offsetY)
    {
        super.update(dt, offsetY);
        getNextPosition();

        x = Math.min(x, 350 - width);
        x = Math.max(x, 0);

        // Top side walls
        if(y >= GameView.HEIGHT - 50)
        {
            if(Game.isStarted)
                dead = true;
            else
            {
                y = GameView.HEIGHT - 50;
                vy = 0;
                onGround = true;
            }
        }

        // Update spirits
        time += dt;
        int frame = (int) (time * frameRate);
        image = (left ? framesL[frame % framesL.length] : framesR[frame % framesR.length]);
    }

    private void getNextPosition()
    {
        // Movement
        if (left)
            ax = -1200;
        else if (right)
            this.ax = 1200;
        else
        {
            ax = 0;
            vx = 0;
        }
    }

    /**
     * La collision avec une plateforme a lieu seulement si :
     *
     * - Il y a une intersection entre la plateforme et le personnage
     *
     * - La collision a lieu entre la plateforme et le *bas du personnage*
     * seulement
     *
     * - La vitesse va vers le bas (le personnage est en train de tomber,
     * pas en train de sauter)
     */

    public boolean testCollisionRed(Platform other, double offsetY)
    {
        if(intersects(other, offsetY) && Math.abs(this.y - (other.y-offsetY)) <= 10)
        {
            pushDown(other, offsetY);
            this.vy = 0; // restrict access by down
            this.onGround = false;
        }
        else if (intersects(other, offsetY) && Math.abs(this.y + height - (other.y-offsetY)) < 10 && vy > 0)
        {
            pushOut(other, offsetY);
            this.vy = 0;
            this.onGround = true;
            return true;
        }

        if(intersects(other, offsetY) && ((this.x + this.width) >= other.x || this.x <= (other.x + other.width)))
        {
            pushOut(other, offsetY);
            this.vy = 0;
            this.onGround = true;
            return true;
        }
        return false;
    }

    public boolean testCollisionGreen(Platform other, double offsetY)
    {
        if (intersects(other, offsetY) && Math.abs(this.y + height - (other.y-offsetY)) < 10 && vy > 0)
        {
            pushOut(other, offsetY);
            this.vy *= -1.5;
            this.onGround = true;
            return true;
        }
        else return false;
    }

    public boolean testPlatformCollision(Platform other, double offsetY)
    {
        if (intersects(other, offsetY) && Math.abs(this.y + height - (other.y-offsetY)) < 10 && vy > 0)
        {
            pushOut(other, offsetY);
            this.vy = 0;
            this.onGround = true;
            return true;
        }
        else return false;
    }

    public boolean testBorderCollision()
    {
        if(this.y >= (GameView.HEIGHT - 50) && !(Game.isStarted))
        {
            this.onGround = true;
            return true;
        }
        else return false;
    }

    public boolean intersects(Platform other, double offsetY)
    {
        return !( x + width < other.x
                        || other.x + other.width < this.x
                        || y + height < (other.y - offsetY)
                        || (other.y - offsetY) + other.height < this.y);
    }

    /**
     * Repousse le personnage vers le haut de la plateforme (sans la déplacer)
     */
    public void pushOut(Platform other, double offsetY)
    {
        double deltaY = this.y + this.height - (other.y-offsetY);
        this.y -= deltaY;
    }


    /**
     * Repousse le personnage vers le bas de la plateforme (sans la déplacer)
     */
    public void pushDown(Platform other, double offsetY)
    {
        double deltaY = this.y - (other.y-offsetY);
        this.y += deltaY;
    }

    public void pushRight(Platform other)
    {
        double deltaX = other.y - this.x;
        this.x += deltaX;
    }

    public void pushLeft(Platform other)
    {
        double deltaX = (this.x + width) - other.y;
        this.x -= deltaX;
    }

    public void onGround(boolean onGround)
    {
        this.onGround = onGround;
    }

    public boolean isOnGround() { return this.onGround; }

    public void jump()
    {
        if(onGround)
        {
            jumping = false;
            onGround = false;
            this.vy = -600;
        }
        else jumping = true;
    }

    @Override
    public void draw(GraphicsContext context, double offsetY)
    {
        if(debug)
        {
            context.setFill(Color.rgb(245, 66, 66, 0.7));
            context.fillRect(x, y, width, height);
        }
        else
        {
            context.setFill(Color.DARKBLUE);
            context.fillRect(x, y, width, height);
        }
        context.drawImage(image, x, y, width, height);

    }
}