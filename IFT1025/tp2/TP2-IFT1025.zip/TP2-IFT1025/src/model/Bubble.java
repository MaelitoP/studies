package model;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

import java.util.Random;

public class Bubble extends Entity
{
    // Attributes
    protected double rayon;
    protected Color color;

    /**
     * Create bubble for animation
     * @param x
     * @param y
     */
    public Bubble(double x, double y)
    {
        this.x = x;
        this.y = y;

        this.rayon = new Random().nextInt((40 - 10) + 1) + 10; // Random between 10-40
        this.color = Color.rgb(0, 0, 255, 0.4);
        this.vy = new Random().nextInt((450 - 350) + 1) + 350; // Random between 350-450
        this.vy = -this.vy;
    }


    @Override
    public void update(double dt, double offsetY)
    {
        super.update(dt, offsetY);
    }

    /**
     * Draw a circle
     * @param context from GameView
     * @param offsetY y *negative* value of the level (not the screen)
     */
    public void draw(GraphicsContext context, double offsetY)
    {
        context.setFill(this.color);
        context.fillOval(x, y, this.rayon, this.rayon);
    }
}