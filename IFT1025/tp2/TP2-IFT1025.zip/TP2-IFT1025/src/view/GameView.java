package view;

import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import model.Jellyfish;
import model.Platform;

public class GameView
{
    public static int WIDTH = 350, HEIGHT = 480;
    private double offsetY, vy, ay;
    private double vySave;
    protected boolean accelerate;
    private Scene scene;
    private Canvas canvas;
    private boolean debug;
    private boolean downTo75;
    private Pane root;
    private Platform acceleratePlat;
    private GraphicsContext gc;

    public GameView()
    {
        this.root = new Pane();
        this.scene = new Scene(root, WIDTH, HEIGHT);
        this.canvas = new Canvas(WIDTH, HEIGHT);
        this.gc = this.canvas.getGraphicsContext2D();
        this.root.getChildren().add(this.canvas);
        this.accelerate = false;
        this.vy = -50;
        this.ay = 0;
        this.offsetY = 0;
    }

    public void reset()
    {
        this.accelerate = false;
        this.vy = -50;
        this.ay = 0;
        this.offsetY = 0;
    }

    public double getOffsetY() { return this.offsetY; }

    public void setOffsetY(double offsetY) { this.offsetY = offsetY; }

    public void setDebug(boolean b)
    {
        if(b)
        {
            vySave = vy;
            vy = 0;
            ay = 0;
        }
        else
        {
            if (vy == 0 && ay == 0)
            {
                vy = vySave;
                ay = 2;
            }
        }
    }

    public void update(double dt, Jellyfish player)
    {
        vy += dt * ay; //TODO Check acc of screen of 2px/s^2 (caused is bugged)
        this.offsetY += dt * vy;

        double playerPos = Math.abs(this.offsetY + player.getY() - (HEIGHT - 50)); // Real player position in relation with offset
        double realScreenY = Math.abs(this.offsetY) + HEIGHT;
        double percent = 0.75 * realScreenY;

        if(accelerate) player.setY(acceleratePlat.getY() - offsetY - 50);
        if(acceleratePlat != null)
            if(!player.testPlatformCollision(acceleratePlat, offsetY) && accelerate && !player.isOnGround())
            {
                vy /= 2;
                accelerate = false;
            }
    }

    public void setVy(double vy) { this.vy = vy; }
    public double getVy() { return this.vy; }

    public void setAccelerate(boolean b, Platform p)
    {
        this.accelerate = b;
        this.acceleratePlat = p;
    }
    public boolean isAccelerate() { return this.accelerate; }

    public void draw()
    {
        this.gc.clearRect(0, 0, WIDTH, HEIGHT);
        this.gc.setFill(Color.DARKBLUE);
        this.gc.fillRect(0, 0, WIDTH, HEIGHT);
    }

    public Scene getScene()
    {
        return this.scene;
    }

    public GraphicsContext getGC()
    {
        return this.gc;
    }
}