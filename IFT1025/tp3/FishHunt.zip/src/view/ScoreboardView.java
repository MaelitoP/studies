package view;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import model.entity.Player;

public class ScoreboardView extends ViewModel
{
    private Button backMenu, addScore;
    private Label titleL, nameL, scoreL;
    private TextField playerNameField;
    private HBox scoreBox;
    private int finalScore = 0;
    private TableView<Player> table;

    private boolean endGame;

    public ScoreboardView(ObservableList<Player> data)
    {
        super();
        this.endGame = false;

        this.backMenu = new Button("Menu");
        this.addScore = new Button("Ajouter!");

        this.titleL = new Label("Meilleurs scores");
        this.titleL.setFont(new Font(25));

        this.nameL = new Label("Votre nom :");
        this.scoreL = new Label();

        this.playerNameField = new TextField();

        this.table = new TableView<>();
        this.table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        // Hide the table header
        this.table.widthProperty().addListener((ObservableValue<? extends Number> ov, Number t, Number t1) -> {
            Pane header = (Pane)table.lookup("TableHeaderRow");
            if(header!=null && header.isVisible())
            {
                header.setMaxHeight(0);
                header.setMinHeight(0);
                header.setPrefHeight(0);
                header.setVisible(false);
                header.setManaged(false);
            }
        });

        this.table.setEditable(false);
        this.table.setMinSize(600, 330);
        this.table.setMaxSize(600, 330);

        TableColumn mainCol = new TableColumn<String, Player>();
        mainCol.setCellValueFactory(new PropertyValueFactory<Player, String>("scoreboard"));
        this.table.setItems(data);
        this.table.getColumns().add(mainCol);

        VBox vbox = new VBox();
        vbox.setSpacing(12);
        vbox.setAlignment(Pos.CENTER);
        vbox.setMinSize(600,430);
        vbox.setPadding(new Insets(20, 0, 0, 20));

        // Box to enter new player score (hidden by default, showed when the player dies)
        this.scoreBox = new HBox();
        this.scoreBox.setSpacing(12);
        this.scoreBox.setAlignment(Pos.CENTER);
        this.scoreBox.getChildren().addAll(this.nameL, this.playerNameField, this.scoreL, this.addScore);

        vbox.getChildren().addAll(this.titleL, this.table, this.scoreBox, this.backMenu);

        this.scoreBox.setVisible(false);
        this.root.getChildren().addAll(vbox);
    }

    public boolean canValidate()
    {
        return !this.playerNameField.getText().trim().isEmpty();
    }

    public TableView<Player> getTableView()
    {
        return this.table;
    }

    public void setScoreBoxVisible(boolean b)
    {
        this.scoreBox.setVisible(b);
    }

    public Button getBackMenuButton()
    {
        return this.backMenu;
    }

    public Button getAddScoreButton()
    {
        return this.addScore;
    }

    public void setScore(int score)
    {
        this.finalScore = score;
        this.scoreL.setText(" a fait " + score + " points!");
    }

    public String getName()
    {
        return this.playerNameField.getText();
    }

    public int getScore()
    {
        return this.finalScore;
    }

    public void draw()
    {
        this.gc.setFill(Color.WHITESMOKE);
        this.gc.fillRect(0, 0, WIDTH, HEIGHT);
    }
}