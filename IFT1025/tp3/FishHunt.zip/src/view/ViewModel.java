package view;

import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Pane;

public abstract class ViewModel
{
    // Attributes
    public int WIDTH = 640, HEIGHT = 480; // FIXED SCREEN SIZE

    public Scene scene;
    public Canvas canvas;
    public Pane root;
    public GraphicsContext gc;

    public ViewModel()
    {
        // Attributes setting
        this.root = new Pane();
        this.scene = new Scene(root, WIDTH, HEIGHT);
        this.canvas = new Canvas(WIDTH, HEIGHT);
        this.gc = this.canvas.getGraphicsContext2D();
        this.root.getChildren().add(this.canvas);

        // Draw scene
        this.draw();
    }

    /**
     * Scene getter
     * @return child scene
     */
    public Scene getScene()
    {
        return this.scene;
    }

    /**
     * Graphic context getter
     * @return child graphic context
     */
    public GraphicsContext getGC()
    {
        return this.gc;
    }

    /**
     * Draw method to design each view
     */
    public abstract void draw();
}
