package view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import model.entity.Fish;

import java.util.List;

public class GameView extends ViewModel
{
    private Label scoreLabel, levelLabel;
    private HBox lifeBox;
    private Image lifeImg1, lifeImg2, lifeImg3;
    private ImageView lifeImgView1, lifeImgView2, lifeImgView3;

    public GameView()
    {
        super(); // Initialize parent view

        Image scope = new Image("./ressources/cible.png");
        ImageView scopeView = new ImageView(scope);
        scopeView.setVisible(false); // Hide scope by default
        scopeView.setFitHeight(50); // Resize image by 50x50
        scopeView.setFitWidth(50);

        // Event
        this.root.setOnMouseMoved((event) -> {
            scopeView.setVisible(true);
            scopeView.setX(event.getX() - (scopeView.getFitWidth()/2));
            scopeView.setY(event.getY() - (scopeView.getFitHeight()/2));
        });

        // Components of game screen (life & level label)
        this.scoreLabel = new Label("");
        this.scoreLabel.setFont(new Font(35));
        this.scoreLabel.setTextFill(Color.WHITE);
        this.scoreLabel.setPadding(new Insets(20, 0, 0, 311));

        this.levelLabel = new Label("Level 1");
        this.levelLabel.setFont(new Font(50));
        this.levelLabel.setTextFill(Color.WHITE);
        this.levelLabel.setPadding(new Insets(200, 0, 0, 245));

        this.lifeImg1 = new Image("./ressources/fish/00.png");
        this.lifeImgView1 = new ImageView(this.lifeImg1);
        this.lifeImg2 = new Image("./ressources/fish/00.png");
        this.lifeImg3 = new Image("./ressources/fish/00.png");
        this.lifeImgView2 = new ImageView(this.lifeImg2);
        this.lifeImgView3 = new ImageView(this.lifeImg3);
        // Resize images in 15x15
        this.lifeImgView1.setFitHeight(30);
        this.lifeImgView1.setFitWidth(30);
        this.lifeImgView2.setFitHeight(30);
        this.lifeImgView2.setFitWidth(30);
        this.lifeImgView3.setFitHeight(30);
        this.lifeImgView3.setFitWidth(30);

        this.lifeBox = new HBox();
        this.lifeBox.setMinSize(640, 200);
        this.lifeBox.setSpacing(5);
        this.lifeBox.setAlignment(Pos.BASELINE_CENTER);
        this.lifeBox.setPadding(new Insets(90, 0, 0, 0));
        this.lifeBox.getChildren().addAll(this.lifeImgView1, this.lifeImgView2, this.lifeImgView3);

        this.root.getChildren().addAll(scopeView, this.lifeBox, this.scoreLabel, this.levelLabel);
    }

    public void setScoreLabel(int score)
    {
        this.scoreLabel.setText(Integer.toString(score));
    }

    public void removeLife()
    {
        if(this.lifeImgView1.isVisible() && this.lifeImgView2.isVisible() && this.lifeImgView3.isVisible())
            this.lifeImgView3.setVisible(false);
        else if(this.lifeImgView1.isVisible() && this.lifeImgView2.isVisible() && !this.lifeImgView3.isVisible())
            this.lifeImgView2.setVisible(false);
        else if(this.lifeImgView1.isVisible() && !this.lifeImgView2.isVisible() && !this.lifeImgView3.isVisible())
            this.lifeImgView1.setVisible(false);
    }

    public void addLife()
    {
        if(this.lifeImgView1.isVisible() && this.lifeImgView2.isVisible() && this.lifeImgView3.isVisible()) return;
        else if(this.lifeImgView1.isVisible() && this.lifeImgView2.isVisible() && !this.lifeImgView3.isVisible())
            this.lifeImgView3.setVisible(true);
        else if(this.lifeImgView1.isVisible() && !this.lifeImgView2.isVisible() && !this.lifeImgView3.isVisible())
            this.lifeImgView2.setVisible(true);
        else if(!this.lifeImgView1.isVisible() && !this.lifeImgView2.isVisible() && !this.lifeImgView3.isVisible())
            this.lifeImgView1.setVisible(true);
    }

    public void drawEntities(List<Fish> entities)
    {
        this.gc.setFill(Color.DARKBLUE);
        this.gc.fillRect(0, 0, WIDTH, HEIGHT);
        for(Fish e : entities)
            this.gc.drawImage(e.getImgView().getImage(), e.getX(), e.getY(), e.getImgView().getFitHeight(), e.getImgView().getFitWidth());

    }

    public void draw()
    {
        this.gc.setFill(Color.DARKBLUE);
        this.gc.fillRect(0, 0, WIDTH, HEIGHT);
    }

    public Label getLevelLabel()
    {
        return this.levelLabel;
    }
}
