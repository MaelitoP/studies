package view;

import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;

public class MenuView extends ViewModel
{
    private Button newGame, scoreboard;

    public MenuView()
    {
        super();

        Image logoImg = new Image("./ressources/logo.png");
        ImageView logo = new ImageView(logoImg);
        logo.setFitHeight(339);
        logo.setFitHeight(253.5);
        logo.setPreserveRatio(true);
        logo.setX(150.5);
        logo.setY(50);

        // New game button
        this.newGame = new Button("Nouvelle partie!");
        this.newGame.setMinWidth(130);
        this.newGame.setLayoutX(255);
        this.newGame.setLayoutY(365);

        // Scoreboard button
        this.scoreboard = new Button("Meilleurs Scores");
        this.scoreboard.setMinWidth(130);
        this.scoreboard.setLayoutX(255);
        this.scoreboard.setLayoutY(400);

        this.root.getChildren().add(this.newGame);
        this.root.getChildren().add(this.scoreboard);
        this.root.getChildren().add(logo);
    }

    public Button getScoreboardButton()
    {
        return this.scoreboard;
    }

    public Button getNewGameButton()
    {
        return this.newGame;
    }

    public void draw()
    {
        this.gc.setFill(Color.DARKBLUE);
        this.gc.fillRect(0, 0, WIDTH, HEIGHT);
    }
}