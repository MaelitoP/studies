package controller;

import javafx.stage.Stage;

import java.io.IOException;

public class Controller
{
    private FileController fileController;
    private GameController gameController;
    private MenuController menuController;

    public Controller(Stage primaryStage)
    {
        try {
            this.fileController = new FileController();
        } catch (IOException e) { e.printStackTrace(); }

        this.menuController = new MenuController();
        this.gameController = new GameController();

        registerEvent(primaryStage);
    }

    public void registerEvent(Stage primaryStage)
    {
        this.menuController.getMenuView().getNewGameButton().setOnAction((event -> {
            primaryStage.setScene(this.gameController.getGameView().getScene());
            this.gameController.getGame().start();
        }));

        this.fileController.getScoreboardView().getBackMenuButton().setOnAction((event -> {
            if(this.gameController.playerIsDead)
            {
                this.gameController.playerIsDead = false;
                this.gameController.getGame().reset();
                this.gameController.restart();
            }
            primaryStage.setScene(this.menuController.getMenuView().getScene());
            this.fileController.getScoreboardView().setScoreBoxVisible(false);
        }));

        this.menuController.getMenuView().getScoreboardButton().setOnAction((event ->
                primaryStage.setScene(this.fileController.getScoreboardView().getScene())
        ));
    }

    public void update(double dt, double dtStart, double dtLevelStart, Stage primaryStage)
    {
        this.gameController.update(dt, dtLevelStart, dtStart);

        if(this.gameController.playerIsDead)
        {
            int score = this.gameController.getPlayer().getScore();
            this.fileController.getScoreboardView().setScore(score);
            this.fileController.getScoreboardView().setScoreBoxVisible(true);
            primaryStage.setScene(this.fileController.getScoreboardView().getScene());
        }
    }

    /* GETTERS & SETTERS */
    public FileController getFileController()
    {
        return this.fileController;
    }

    public GameController getGameController()
    {
        return this.gameController;
    }

    public MenuController getMenuController()
    {
        return this.menuController;
    }
}