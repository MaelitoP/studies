package controller;

import view.MenuView;

public class MenuController
{
    private MenuView menuV;

    public MenuController()
    {
        menuV = new MenuView();
    }

    /* GETTERS & SETTERS */
    public MenuView getMenuView()
    {
        return this.menuV;
    }
}
