package controller;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.Pane;
import model.Game;
import model.entity.*;
import view.GameView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GameController
{
    // Attributes
    private List<Ball> balls = new ArrayList<>();
    private List<Fish> fishes = new ArrayList<>();
    private List<Bubble> bubbles = new ArrayList<>();

    private List<Ball> ballsDead = new ArrayList<>();
    private List<Fish> fishesDead = new ArrayList<>();
    private List<Bubble> bubblesDead = new ArrayList<>();

    private boolean canGoToNextLevel = true;
    private double deltaSinceNextLevel = 0;

    public boolean playerIsDead = false;

    // View
    GameView gameV;

    // Model
    Game game;
    Player player;

    /**
     * Game controller constructor
     */
    public GameController()
    {
        restart();
    }

    /**
     * Restart the game
     * Re-initialize all instances & values
     */
    public void restart()
    {
        // Initialize views
        this.gameV = new GameView();

        // Initialize models
        this.game = new Game();
        this.player = new Player(null, 0, 0);

        // Initialize score on screen
        this.gameV.setScoreLabel(this.player.getScore());

        // Event
        registerEvent();

        clearMemory();
    }

    /**
     * Update all objects each ticks
     * @param dt tick (second)
     * @param dtStart time since the application have been launch
     * @param dtLevelStart time since the first level is started
     */
    public void update(double dt, double dtStart, double dtLevelStart)
    {
        if(this.game.isStarted())
        {
            // First 3 seconds of level
            if(dtLevelStart >= 2.9 * Math.pow(10, 9) && this.gameV.getLevelLabel().isVisible() && this.game.getLevel() == 1)
                this.gameV.getLevelLabel().setVisible(false);

            if(this.deltaSinceNextLevel != 0 && dtLevelStart >= this.deltaSinceNextLevel + (2.9 * Math.pow(10, 9))
                                                  && this.gameV.getLevelLabel().isVisible())
                this.gameV.getLevelLabel().setVisible(false);

            // Update fishes position
            fishes.forEach(fish -> {
                fish.update(dt, dtStart);

                // Check if the fish is out of the screen
                if(fish.getX()+fish.getWidth() < 0 || fish.getX() > 640)
                {
                    this.player.removeLife(); // Remove 1 life in data
                    this.gameV.removeLife(); // Remove 1 life icon on the screen
                    fishesDead.add(fish);
                    if(this.player.isDead()) this.playerDie();
                }
            });
            this.gameV.drawEntities(fishes);

            // Update balls position
            balls.forEach(ball -> {
                ball.update(dt, dtStart);
                ball.draw(this.gameV.getGC(), null);

                // Check if the player hit a fish
                if(ball.getRadius() == 0)
                {
                    fishes.forEach(fish -> {
                        if(ball.collision(fish))
                        {
                            this.player.incrementScore();
                            this.gameV.setScoreLabel(this.player.getScore());
                            ballsDead.add(ball);
                            fishesDead.add(fish);
                        }
                        else ballsDead.add(ball);

                    });
                }
            });

            // Update game level
            if(this.player.getScore() != 0 && this.player.getScore()%5 == 0 && canGoToNextLevel)
            {
                this.game.nextLevel();
                deltaSinceNextLevel = dtLevelStart;
                this.gameV.getLevelLabel().setText("Level " + this.game.getLevel());
                this.gameV.getLevelLabel().setVisible(true);
                canGoToNextLevel = false;
            }
            else if(this.player.getScore()%5 != 0 && !canGoToNextLevel)
                canGoToNextLevel = true;

            // Bubble animation
            updateBubbles(dt, dtStart);
            drawBubbles(this.gameV.getGC(), null);

            bubbles.forEach(bubble -> {
                if(bubble.getY() - bubble.getRadius() < 0)
                    bubblesDead.add(bubble);
            });

            // Update & clear memory
            balls.removeAll(ballsDead);
            fishes.removeAll(fishesDead);
            bubbles.removeAll(bubblesDead);
            ballsDead.clear();
            fishesDead.clear();
            bubblesDead.clear();
        }
    }

    /**
     * Update bubbles animation
     * @param dt
     */
    public void updateBubbles(double dt, double dtStart)
    {
        // Bubbles
        if(bubbles.size() == 0) return;
        for(int i = 0; i < bubbles.size(); i++)
            bubbles.get(i).update(dt, dtStart);
    }

    /**
     * Draw the bubbles in the background of the level
     * @param context
     */
    public void drawBubbles(GraphicsContext context, Pane pane)
    {
        // Bubbles
        if(bubbles.size() == 0) return;
        for(int i = 0; i < bubbles.size(); i++)
            bubbles.get(i).draw(context, pane);
    }

    /**
     * Send bubbles
     *  - 3 groups of 5 bubbles each
     */
    public void sendBubble()
    {
        int i = 0;

        while(i < 4) // Make 3 groups
        {
            double baseX = new Random().nextInt(641); // Random x pos
            for(int j = 0; j < 6; j++)
            {
                int sign = new Random().nextInt((2-1) + 1) + 1; // Random sign (1: +, 2: -)

                double x = (sign == 1) ? (baseX + 20) : (baseX - 20);
                double y = 440;
                bubbles.add(new Bubble(x, y));
            }
            i++;
        }
    }

    /**
     * Delete all created objects
     */
    public void clearMemory()
    {
        balls.clear();
        fishes.clear();
        bubbles.clear();
    }

    /**
     * Call the die to reset the game
     */
    public void playerDie()
    {
        // Turn off the game
        this.game.reset();
        this.playerIsDead = true;
    }

    /**
     * Get a random number between [0-1] range
     * @return random integer
     */
    public int getRandomNumber()
    {
        return Math.abs(new Random().nextInt(2) - 1);
    }

    /**
     * Add a new entity in the game
     * @param special add special entity (crab or starfish)
     */
    public void addEntities(boolean special)
    {
        int side = getRandomNumber(); // Give random number between 0 & 1
        double x = (side == 0) ? 639 : -99;
        Random r = new Random();
        double y = ((double)1/5)*480 + (((double)4/5)*480 - ((double)1/5)*480) * r.nextDouble(); // Give random y pos

        if(special)
        {
            int entityType = getRandomNumber(); // 0: Crab 1: Starfish
            if(entityType == 0)
                fishes.add(new Crab(x, y, game.getLevel(), side));
            else
                fishes.add(new Starfish(x, y, game.getLevel(), side));
        }
        else  fishes.add(new Fish(x, y, game.getLevel(), side, true));
    }

    /**
     * Catch mouse event to throw bullet on fishes
     */
    public void registerEvent()
    {
        this.gameV.getScene().setOnMouseClicked(e -> {
            if(e.getButton() == MouseButton.PRIMARY)
            {
                if(this.game.isStarted())
                {
                    // Launch a 'bullet' each left mouse click
                    Ball b = new Ball(e.getX(), e.getY());
                    balls.add(b);
                }
            }
        });

        // Setting debug key
        this.gameV.getScene().setOnKeyPressed(e -> {
            switch(e.getCode())
            {
                // Go to next level
                case H:
                    while(this.player.getScore()%5 != 0)
                        this.player.incrementScore();
                    this.gameV.setScoreLabel(this.player.getScore());
                    break;
                // Increment player score
                case J:
                    this.player.incrementScore();
                    this.gameV.setScoreLabel(this.player.getScore());
                    break;
                // Give 1 life
                case K:
                    this.player.incrementLife();
                    this.gameV.addLife();
                    break;
                // Lose the game
                case L:
                    for(int i = this.player.getLife(); i >= 0; i--)
                        this.player.removeLife();
                    this.playerDie();
                    break;
            }
        });
    }

    /* GETTERS & SETTERS */
    public Game getGame()
    {
        return this.game;
    }

    public Player getPlayer()
    {
        return this.player;
    }

    public GameView getGameView()
    {
        return this.gameV;
    }
}