package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.entity.Player;
import utils.MapHelpers;
import view.ScoreboardView;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class FileController
{
    // Attributes
    private HashMap<String, Integer> scoreboard;
    private ObservableList<Player> data;
    private File file;

    private ScoreboardView scoreboardV;

    /**
     * Setting scoreboard of FishHunt
     * @throws IOException
     */
    public FileController() throws IOException
    {
        this.scoreboard = new HashMap<>();
        this.data = FXCollections.observableArrayList();
        init();
        this.scoreboardV = new ScoreboardView(this.data);
        registerEvent();
    }

    public void registerEvent()
    {
        this.scoreboardV.getAddScoreButton().setOnAction((event) -> {
            if(this.scoreboardV.canValidate() && this.scoreboardV.getScore() != 0) // Check if TextField is empty
            {
                try {
                    // Save the new score in the file & update current TableView
                    this.data.clear();
                    write(this.scoreboardV.getName(), this.scoreboardV.getScore());
                    read();
                    sortData();
                } catch (IOException e) { e.printStackTrace(); }

            }
        });
    }

    /**
     * Initialize scoreboard file
     * @throws IOException
     */
    public void init() throws IOException
    {
        this.file = new File("scoreboard.txt");

        // Create the file if doesn't exist
        if (this.file.createNewFile())
            System.out.println("[INFO] Scoreboard file created !");
        else System.out.println("[INFO] Scoreboard file initialized !");

        read();
        sortData();
    }

    /**
     * Load all score saved in the {scoreboard.txt} file
     * @throws IOException
     */
    public void read() throws IOException
    {
        Scanner sc = new Scanner(this.file);

        while(sc.hasNextInt())
        {
            int score = sc.nextInt();
            String name = sc.next();
            this.scoreboard.put(name, score);
        }
        sc.close();
    }

    public void sortData()
    {
        int count = 1;
        Map<String, Integer> newMap = MapHelpers.sortByComparator(this.scoreboard, false);
        for(String name : newMap.keySet())
        {
            this.data.add(new Player(name, newMap.get(name), count));
            count++;
        }
    }

    /**
     * Write the player score in scoreboard file
     * @param name
     *        Player name
     * @param score
     *        Player score
     * @throws IOException
     */
    public void write(String name, int score) throws IOException
    {
        OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(this.file), "UTF-8");
        BufferedWriter bufWriter = new BufferedWriter(writer);

        for(String key : this.scoreboard.keySet())
        {
            bufWriter.write(this.scoreboard.get(key) + " " + key);
            bufWriter.newLine();
        }

        bufWriter.write(score + " " + name);
        bufWriter.close();

        this.scoreboard.clear();
        read();
    }

    /**
     * Getter of serialized scoreboard
     * @return HahsMap with key: player name & value: score
     */
    public HashMap<String, Integer> getScoreboard()
    {
        return this.scoreboard;
    }

    /* GETTERS & SETTERS */
    public ScoreboardView getScoreboardView()
    {
        return this.scoreboardV;
    }
}
