package model.entity;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

public class Ball extends Entity
{
    private double radius;
    private double velocity;

    public Ball(double x, double y)
    {
        this.x = x;
        this.y = y;

        this.radius = 50; // First size
        this.velocity = 300; // Velocity of 300px/s
        this.color = Color.BLACK;
    }

    /**
     * Check intersection between entities
     * @param other entity
     * @return boolean if we have a collision
     */
    public boolean collision(Entity other)
    {
        return (this.radius == 0 && (x > other.x && x < other.x + other.width)
                && (y > other.y && y < other.y + other.height));
    }

    @Override
    public void update(double dt, double dtStart)
    {
        this.radius -= dt * this.velocity;
        if(this.radius <= 0) {
            this.radius = 0;
            this.velocity = 0;
        }
    }

    public void draw(GraphicsContext context, Pane pane)
    {
        context.setFill(this.color);
        context.fillOval(this.x-(this.radius/2), this.y-(this.radius/2), this.radius, this.radius);
    }

    public double getRadius()
    {
        return this.radius;
    }
}
