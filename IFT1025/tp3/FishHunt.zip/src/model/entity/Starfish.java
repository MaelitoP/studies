package model.entity;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import utils.ImageHelpers;

import java.util.concurrent.TimeUnit;

public class Starfish extends Fish
{
    private double initPositionY;
    private boolean up = false; boolean down = false, yIsInit = false;

    public Starfish(double x, double y, int level, int direction)
    {
        super(x, y, level, direction, false);

        this.ay = 0;
        this.vy = 200;
        this.initPositionY = y;
        this.yIsInit = true;

        // Set crab image
        this.img = new Image("./ressources/star.png");

        // Change the rotation of the fish if he'll spawn on the right side
        if(this.direction == 0)
            img = ImageHelpers.flop(img);

        this.imgView = new ImageView(img);
        this.imgView.setFitWidth(100);
        this.imgView.setFitHeight(100);
        this.imgView.setPreserveRatio(true);
    }

    @Override
    public void update(double dt, double dtStart)
    {
        vx += dt * ax;
        vy += dt * ay;

        if(this.direction == 0)
            x -= dt * vx;
        else x += dt * vx;

        if(!up && !down)
            up = true;

        if(up){
            if(y < (initPositionY)-50) {
                up = false;
                down = true;
                y += dt * vy;
            }else
                y -= dt * vy;
        }else if(down){
            if(y > (initPositionY) + 50){
                up = true;
                down = false;
                y -= dt * vy;
            }else
                y += dt * vy;
        }

        this.imgView.setX(x);
        this.imgView.setY(y);
    }

    public void draw(GraphicsContext context, Pane pane)
    {
        pane.getChildren().add(this.imgView);
    }
}
