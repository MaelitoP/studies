package model.entity;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import utils.ImageHelpers;

import java.util.Random;

public class Fish extends Entity
{
    public Image img;
    public ImageView imgView;
    public int direction;

    /**
     * Create fish entity
     * @param x
     * @param y
     * @param level game level
     * @param direction 0: Right 1: Left
     */
    public Fish(double x, double y, int level, int direction, boolean randomColor)
    {
        this.x = x;
        this.y = y;
        this.width = 100;
        this.height = 100;
        this.direction = direction;

        this.ay = 100;
        this.vx = 100 * Math.pow(level, 1/3) + 200;
        this.vy = -new Random().nextInt((200 - 100) + 1) + 100; // Random velocity y between [100-200px/s]

        // Select random image of fish to represent it
        int imageValue = new Random().nextInt(8);
        this.img = new Image("./ressources/fish/0" + imageValue + ".png");

        // Change the rotation of the fish if he'll spawn on the right side
        if(this.direction == 0)
            this.img = ImageHelpers.flop(this.img);

        // Random Color
        if(randomColor)
        {
            this.color = new Color(Math.random(), Math.random(), Math.random(), 1);
            this.img = ImageHelpers.colorize(this.img, this.color);
        }

        // ImageView config
        this.imgView = new ImageView(img);
        this.imgView.setFitWidth(100);
        this.imgView.setFitHeight(100);
        this.imgView.setPreserveRatio(true);
    }

    @Override
    public void update(double dt, double dtStart)
    {
        super.update(dt, dtStart);

        if(this.direction == 0)
            x -= dt * vx;
        else x += dt * vx;

        this.imgView.setX(x);
        this.imgView.setY(y);
    }

    public void draw(GraphicsContext context, Pane pane) { }

    public ImageView getImgView()
    {
        return this.imgView;
    }
}
