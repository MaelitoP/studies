package model.entity;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import utils.ImageHelpers;

import java.util.concurrent.TimeUnit;

public class Crab extends Fish
{
    private double count = 0;
    private double next25 = 250;
    private double inter50Rule = 0, inter25Rule = 0;
    private boolean lastWasForward = false, lastWasBackward = false, canBack = false;

    public Crab(double x, double y, int level, int direction)
    {
        super(x, y, level, direction, false);

        this.ay = 0;
        this.vx *= 1.3;
        this.vy = 0;

        // Set crab image
        this.img = new Image("./ressources/crabe.png");

        // Change the rotation of the fish if he'll spawn on the right side
        if(this.direction == 0)
            img = ImageHelpers.flop(img);

        this.imgView = new ImageView(img);
        this.imgView.setFitWidth(100);
        this.imgView.setFitHeight(100);
        this.imgView.setPreserveRatio(true);
    }

    public void increment(double dt)
    {
        if(direction == 0)
            x -= dt * vx;
        else x += dt * vx;
    }

    public void decrement(double dt)
    {
        if(direction == 0)
            x += dt * vx;
        else x -= dt * vx;
    }

    @Override
    public void update(double dt, double dtStart)
    {
        vx += dt * ax;
        vy += Math.pow(dt, 2) * ay;

        if(TimeUnit.MILLISECONDS.convert((long)(dtStart), TimeUnit.NANOSECONDS) >= next25 )
        {
            count += 250;
            next25 += 250;

            if(lastWasForward)
            {
                inter50Rule += 1;
                if(inter50Rule == 2)
                {
                    canBack = true;
                    inter50Rule = 0;
                }
            }

            if(lastWasBackward)
            {
                inter25Rule += 1;
                if(inter25Rule == 1)
                {
                    canBack = false;
                    inter25Rule = 0;
                }
            }
        }

        if(count == 0)
        {
            increment(dt);
            lastWasForward = true;
            lastWasBackward = false;

        }
        else if(count >= 500 && count % 250 == 0 && canBack)
        {
            decrement(dt);
            lastWasForward = false;
            lastWasBackward = true;

        }
        else if(count >= 500 && count % 250 == 0)
        {
            increment(dt);
            lastWasForward = true;
            lastWasBackward = false;
        }

        this.imgView.setX(x);
        this.imgView.setY(y);
    }

    public void draw(GraphicsContext context, Pane pane)
    {
        pane.getChildren().add(this.imgView);
    }
}