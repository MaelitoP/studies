package model.entity;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

import java.util.Random;

public class Bubble extends Entity
{
    // Attributes
    protected double radius;
    protected Color color;

    /**
     * Create bubble for animation
     * @param x
     * @param y
     */
    public Bubble(double x, double y)
    {
        this.x = x;
        this.y = y;

        this.radius = new Random().nextInt((40 - 10) + 1) + 10; // Random between 10-40
        this.color = Color.rgb(0, 0, 255, 0.4);
        this.vy = new Random().nextInt((450 - 350) + 1) + 350; // Random between 350-450
        this.vy = -this.vy;
    }

    @Override
    public void update(double dt, double dtStart)
    {
        super.update(dt, dtStart);
    }

    /**
     * Draw a circle
     * @param context from GameView
     */
    public void draw(GraphicsContext context, Pane pane)
    {
        context.setFill(this.color);
        context.fillOval(x, y, this.radius, this.radius);
    }

    public double getY()
    {
        return this.y;
    }

    public double getRadius()
    {
        return this.radius;
    }
}