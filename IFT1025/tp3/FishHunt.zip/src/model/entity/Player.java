package model.entity;

public class Player
{
    private String name;
    private int life;
    private int score;
    private int place;
    private boolean dead;
    private String scoreboard;

    public Player(String name, int score, int place)
    {
        reset();
        if(name != null && score != 0 && place !=0)
        {
            this.name = name;
            this.score = score;
            this.place = place;
            this.scoreboard = "#" + this.place + " - " + this.name + " - " + this.score;
        }
    }

    public void reset()
    {
        this.name = "";
        this.life = 3;
        this.score = 0;
        this.dead = false;
    }

    public void removeLife()
    {
        this.life--;
        if(this.life == 0) this.dead = true;
    }

    public void incrementLife()
    {
        if(life < 3) life++;
    }

    public void incrementScore()
    {
        this.score++;
    }

    /* GETTERS & SETTERS */
    public int getScore()
    {
        return this.score;
    }

    public boolean isDead()
    {
        return this.dead;
    }

    public String getScoreboard()
    {
        return this.scoreboard;
    }

    public String getName()
    {
        return this.name;
    }

    public int getLife()
    {
        return this.life;
    }

    public void setName(String name)
    {
        this.name = name;
    }
}
