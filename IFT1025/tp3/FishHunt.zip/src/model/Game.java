package model;

public class Game
{
    private boolean isStarted;
    private boolean newLevel;
    private int level;

    public Game()
    {
        this.reset();
    }

    public void reset()
    {
        this.isStarted = false;
        this.level = 1;
        this.newLevel = true;
    }

    public void nextLevel()
    {
        this.level++;
        this.newLevel = true;
    }

    public boolean isNewLevel()
    {
        return this.newLevel;
    }

    public void setNewLevel(boolean b)
    {
        this.newLevel = b;
    }

    public void start()
    {
        this.isStarted = true; // Set game start
    }

    public boolean isStarted()
    {
        return this.isStarted;
    }

    public int getLevel()
    {
        return this.level;
    }
}