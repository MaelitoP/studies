package model;

public class Game
{
    private boolean isStarted;

    public Game()
    {

    }

    public void update()
    {

    }

    public void start()
    {
        this.isStarted = true; // Set game start
    }

    public boolean isStarted()
    {
        return this.isStarted;
    }
}
