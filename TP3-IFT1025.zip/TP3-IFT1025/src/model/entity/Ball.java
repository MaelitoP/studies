package model.entity;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

public class Ball extends Entity
{
    private double radius;
    private double velocity;

    public Ball(double x, double y)
    {
        this.x = x;
        this.y = y;

        this.radius = 50; // First size
        this.velocity = 300; // Velocity of 300px/s
        this.color = Color.BLACK;
    }

    public double getRadius()
    {
        return this.radius;
    }

    @Override
    public void update(double dt)
    {
        this.radius -= dt * this.velocity;
        if(this.radius <= 0) this.velocity = 0;
    }

    public void draw(GraphicsContext context, Pane pane)
    {
        context.setFill(Color.DARKBLUE);
        context.fillRect(this.x-50, this.y-50, 100, 100);
        context.setFill(this.color);
        context.fillOval(this.x-(this.radius/2), this.y-(this.radius/2), this.radius, this.radius);
    }
}
