package model.entity;

public class Player
{
    private String name;
    private int score;

    public Player()
    {

    }

    public String getName()
    {
        return this.name;
    }

    public int getScore()
    {
        return this.score;
    }

    public void setScore(int score)
    {
        this.score = score;
    }

    public void setName(String name)
    {
        this.name = name;
    }
}
