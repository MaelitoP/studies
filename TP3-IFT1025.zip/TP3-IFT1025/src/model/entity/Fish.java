package model.entity;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import utils.ImageHelpers;

import java.util.Random;

public class Fish extends Entity
{
    private Image img;
    private ImageView imgView;
    private int direction;

    /**
     * Create fish entity
     * @param x
     * @param y
     * @param level game level
     * @param direction 0: Right 1: Left
     */
    public Fish(double x, double y, int level, int direction)
    {
        this.x = x;
        this.y = y;
        this.direction = direction;

        this.ay = 100;
        this.vx = 100 * Math.pow(level, 1/3) + 200;
        this.vy = new Random().nextInt((200 - 100) + 1) + 100; // Random velocity y between [100-200px/s]

        // Select random image of fish to represent it
        int imageValue = new Random().nextInt(8);
        img = new Image("./ressources/fish/0" + imageValue + ".png");

        // Change the rotation of the fish if he'll spawn on the right side
        if(this.direction == 0) {
            img = ImageHelpers.flop(img);
        }

        this.imgView = new ImageView(img);
        this.imgView.setFitWidth(100);
        this.imgView.setFitHeight(100);
        this.imgView.setPreserveRatio(true);
    }

    @Override
    public void update(double dt)
    {
        super.update(dt);

        if(this.direction == 0)
            x -= dt * vx;
        else x += dt * vx;

        this.imgView.setX(x);
        this.imgView.setY(y);
    }

    public void draw(GraphicsContext context, Pane pane)
    {
        pane.getChildren().add(this.imgView);
    }
}
