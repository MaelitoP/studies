package model.entity;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Pane;

public class Starfish extends Entity
{
    public Starfish(double x, double y)
    {

    }

    public void draw(GraphicsContext context, Pane pane)
    {

    }
}
