package model.entity;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

public abstract class Entity
{
    // Attributes
    protected double width, height;
    protected double x, y;

    protected double vx, vy;
    protected double ax, ay;

    protected Color color;

    /**
     * Update pos & velocity each tick
     * @param dt time out since last update()
     */
    public void update(double dt)
    {
        vx += dt * ax;
        vy += Math.pow(dt, 2) * ay;

        y += dt * vy;
    }

    /**
     * Draw method to design each entities by children class
     * @param context from GameView
     */
    public abstract void draw(GraphicsContext context, Pane pane);
}
