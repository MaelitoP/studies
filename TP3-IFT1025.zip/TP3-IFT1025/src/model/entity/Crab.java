package model.entity;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Pane;

public class Crab extends Entity
{
    public Crab(double x, double y)
    {

    }

    public void draw(GraphicsContext context, Pane pane)
    {

    }
}
