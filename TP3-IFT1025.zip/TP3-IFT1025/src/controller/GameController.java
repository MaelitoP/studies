package controller;

import javafx.scene.input.MouseButton;
import model.Game;
import model.entity.Ball;
import model.entity.Entity;
import model.entity.Fish;
import view.GameView;
import view.MenuView;
import view.ScoreboardView;

import java.util.ArrayList;
import java.util.List;

public class GameController
{
    public List<Ball> balls = new ArrayList<>();
    public List<Fish> fishs = new ArrayList<>();

    // Views
    MenuView menuV;
    ScoreboardView scoreboardV;
    GameView gameV;

    // Model
    Game game;

    public GameController()
    {
        // Initialize views
        this.menuV = new MenuView();
        this.scoreboardV = new ScoreboardView();
        this.gameV = new GameView();

        // Initialize models
        this.game = new Game();

        // Event
        registerEvent();
    }

    public void update(double dt)
    {
        if(this.game.isStarted())
        {
            // Update balls position
            balls.forEach(ball -> {
                ball.update(dt);
                ball.draw(this.gameV.getGC(), null);
            });

            fishs.forEach(fish -> {
                fish.update(dt);
            });
        }
    }

    public void registerEvent()
    {
        this.gameV.getScene().setOnMouseClicked(e -> {
            if(e.getButton() == MouseButton.PRIMARY)
            {
                if(this.game.isStarted())
                {
                    Ball b = new Ball(e.getX(), e.getY());
                    balls.add(b);
                    Fish t = new Fish(500, 100, 1, 0);
                    t.draw(null, this.gameV.getPane());
                    fishs.add(t);
                }
            }
        });
    }

    /* GETTERS & SETTERS */
    public Game getGame()
    {
        return this.game;
    }

    public MenuView getMenuView()
    {
        return this.menuV;
    }

    public ScoreboardView getScoreboardView()
    {
        return this.scoreboardV;
    }

    public GameView getGameView()
    {
        return this.gameV;
    }
}
