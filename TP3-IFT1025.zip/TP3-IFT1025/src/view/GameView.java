package view;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;

public class GameView extends ViewModel
{
    public GameView()
    {
        super(); // Initialize parent view

        Image scope = new Image("./ressources/cible.png");
        ImageView scopeView = new ImageView(scope);
        scopeView.setVisible(false); // Hide scope by default
        scopeView.setFitHeight(50); // Resize the scope by 50x50
        scopeView.setFitWidth(50);

        // Event
        this.root.setOnMouseMoved((event) -> {
            scopeView.setVisible(true);
            scopeView.setX(event.getX() - (scopeView.getFitWidth()/2));
            scopeView.setY(event.getY() - (scopeView.getFitHeight()/2));
        });

        this.root.getChildren().add(scopeView);
    }

    public void draw()
    {
        this.gc.setFill(Color.DARKBLUE);
        this.gc.fillRect(0, 0, WIDTH, HEIGHT);
    }
}
