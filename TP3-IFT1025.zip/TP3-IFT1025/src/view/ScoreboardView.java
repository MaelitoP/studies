package view;

public class ScoreboardView {
}
