import controller.GameController;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * FishHunt Game for IFT1025 course
 * @author Maël LE PETIT
 *         Alex BUSSING
 * @version 1.0.0
 */
public class FishHunt extends Application
{
    GameController controller;
    ScheduledExecutorService executor;

    @Override
    public void start(Stage primaryStage)
    {
        primaryStage.setTitle("Fish Hunt");
        primaryStage.setResizable(false);
        primaryStage.getIcons().add(new Image("/ressources/fish/00.png"));

        controller = new GameController();

        AnimationTimer timer = new AnimationTimer()
        {
            private long lastTime = 0;

            // Game thread
            @Override
            public void handle(long now)
            {
                if (lastTime == 0)
                {
                    lastTime = now;
                    return;
                }

                double deltaTime = (now - lastTime) * 1e-9; // Get time in seconds

                controller.update(deltaTime);

                lastTime = now; // interval every frame
            }
        };
        timer.start();

        controller.getMenuView().getNewGameButton().setOnAction((event -> {
            primaryStage.setScene(controller.getGameView().getScene());
            controller.getGame().start();
        }));

        primaryStage.setScene(controller.getMenuView().getScene());
        primaryStage.show();
    }

    public static void main(String[] args)
    {
        launch(args);
    }
}